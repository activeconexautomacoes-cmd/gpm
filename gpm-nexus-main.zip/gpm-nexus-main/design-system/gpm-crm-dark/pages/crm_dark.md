# Crm Dark Page Overrides

> **PROJECT:** GPM CRM Dark
> **Generated:** 2026-01-25 01:07:38
> **Page Type:** General

> ⚠️ **IMPORTANT:** Rules in this file **override** the Master file (`design-system/MASTER.md`).
> Only deviations from the Master are documented here. For all other rules, refer to the Master.

---

## Page-Specific Rules

### Layout Overrides

- **Max Width:** 1200px (standard)
- **Layout:** Full-width sections, centered content
- **Sections:** 1. Intro (Vertical), 2. The Journey (Horizontal Track), 3. Detail Reveal, 4. Vertical Footer

### Spacing Overrides

- No overrides — use Master spacing

### Typography Overrides

- No overrides — use Master typography

### Color Overrides

- **Strategy:** Continuous palette transition. Chapter colors. Progress bar #000000.

### Component Overrides

- Avoid: Gray text on gray background
- Avoid: Wide tables breaking layout
- Avoid: Low contrast text

---

## Page-Specific Components

- No unique components for this page

---

## Recommendations

- Effects: Minimal glow (text-shadow: 0 0 10px), dark-to-light transitions, low white emission, high readability, visible focus
- Typography: Use darker text on light backgrounds
- Responsive: Use horizontal scroll or card layout
- Accessibility: Minimum 4.5:1 ratio for normal text
- CTA Placement: Floating Sticky CTA or End of Horizontal Track
